AURORA TV OS - Android launcher wrapper project
This source project is prepared for Android 6.0+ (API 23). It is NOT a compiled APK.
To build: open this folder in Android Studio with Android SDK installed, or upload the folder to a GitHub repository and run the 'Build AURORA APK' workflow under Actions.
The APK output is app/build/outputs/apk/debug/app-debug.apk.
Important: This app is a WebView launcher. It cannot switch physical HDMI/AV inputs, control Wi-Fi, or guarantee replacing the TV's default launcher. Use the TV remote's Source/Input key for HDMI 3 and AV.
